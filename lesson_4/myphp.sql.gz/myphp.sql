-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 22 2020 г., 22:04
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `myphp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `id_item` int NOT NULL,
  `count` int NOT NULL,
  `id_user` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `id_item` int NOT NULL,
  `price` int NOT NULL,
  `adress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `id_user`, `id_item`, `price`, `adress`, `date_created`, `order_status`) VALUES
(25, 40, 1, 300, 'asd', '2020-11-23 23:50:47', 2),
(26, 40, 2, 1332, 'asd', '2020-11-23 23:50:47', 2),
(28, 40, 1, 100, 'dsadwq', '2020-11-23 23:51:14', 3),
(29, 40, 2, 1332, 'dsadwq', '2020-11-23 23:51:14', 3),
(31, 40, 2, 666, 'dagew', '2020-11-23 23:51:54', 3),
(32, 40, 1, 100, 'dagew', '2020-11-23 23:51:54', 3),
(34, 40, 2, 666, 'фыв', '2020-11-26 18:11:35', 1),
(35, 40, 1, 100, 'фыв', '2020-11-26 18:11:35', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `shop`
--

CREATE TABLE `shop` (
  `id` int NOT NULL,
  `product_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `short_desc` text COLLATE utf8mb4_general_ci NOT NULL,
  `long_desc` text COLLATE utf8mb4_general_ci NOT NULL,
  `in_storage` int NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `shop`
--

INSERT INTO `shop` (`id`, `product_name`, `img`, `short_desc`, `long_desc`, `in_storage`, `price`) VALUES
(1, 'Computer', '1.jpg', 'Nice for work', 'Very good PC. You should buy it.', 34, 400),
(2, 'It specialist', '2.jpg', 'Slave', 'Your personal it slave. Can fix 10 printers at a time!', 2, 666),
(6, 'MSI PC', '3.jpglxfjn1', 'MSI Gaming PC', 'MSI Gaming PC', 100, 600),
(7, 'Playstation 4', '4.jpglxfjn1', 'PS4', 'PS4', 100, 550),
(8, 'Xbox series X', '5.jpglxfjn1', 'Brand new X', 'Brand new X', 100, 550),
(9, 'Samsung Galaxy s20', '6.jpglxfjn1', 'New with 3 cameras', 'New with 3 cameras', 100, 450),
(10, 'Apple iPhone 12', '7.jpglxfjn1', 'OMG So cool', 'OMG So cool', 100, 9999);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `user_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `admin_status` int NOT NULL,
  `first_name` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `cookie` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `admin_status`, `first_name`, `cookie`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b14rsdgxcvnbmth4', 1, 'admin', ''),
(40, 'Vasya', '827ccb0eea8a706c4c34a16891f84e7b14rsdgxcvnbmth4', 0, 'Vasya', 'login=Vasya'),
(41, 'Petya', '827ccb0eea8a706c4c34a16891f84e7b14rsdgxcvnbmth4', 0, 'Petr', 'login=Petya');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `shop`
--
ALTER TABLE `shop`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
